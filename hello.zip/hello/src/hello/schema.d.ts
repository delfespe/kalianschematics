export interface Schema{
    name:string;
}