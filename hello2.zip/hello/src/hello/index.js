"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const exception_1 = require("@angular-devkit/schematics/src/exception/exception");
// You don't have to export the function as default. You can also have more than one rule factory per file.
//1. No usa la interface Schema
/* export function hello(_options: any): Rule {
  return (tree: Tree, _context: SchematicContext) => {
    const {name} = _options;
    tree.create('hello.js',`console.log('Hello ${name}}!');`);
    return tree;
  };
}
 */
//2. Valida las opciones con Schema
//Ubicarse ./src/hello y ejecutar npx -p dtsgenerator dtsgen schema.json -o schema.d.ts
/* export function hello(_options: Schema): Rule {
  return (tree: Tree, _context: SchematicContext) => {
    const {name} = _options;
    tree.create('hello.js',`console.log('Hello ${name}!');`);
    return tree;
  };
}
 */
//3. usando templates
// schematics .:hello --debug=false --force
function hello(_options) {
    return (tree, _context) => {
        const workspaceConfigBuffer = tree.read("angular.json");
        if (!workspaceConfigBuffer) {
            throw new exception_1.SchematicsException("No es un proyecto angular");
        }
        //const workspaceConfig = JSON.parse(workspaceConfigBuffer.toString());
        const sourceTemplate = schematics_1.url('./files');
        const sourceParametrizedTemplates = schematics_1.apply(sourceTemplate, [schematics_1.template(Object.assign({}, _options, core_1.strings, { addExclamation }))]);
        return schematics_1.mergeWith(sourceParametrizedTemplates)(tree, _context); //une el template con el arbol
    };
    function addExclamation(value) {
        return value + '!';
    }
}
exports.hello = hello;
//# sourceMappingURL=index.js.map