import { Rule, SchematicContext, Tree, url, apply, template, mergeWith } from '@angular-devkit/schematics';
import { Schema } from './schema';
import { SchematicsException } from '@angular-devkit/schematics/src/exception/exception';


// You don't have to export the function as default. You can also have more than one rule factory per file.

//1. No usa la interface Schema
/* export function hello(_options: any): Rule {
  return (tree: Tree, _context: SchematicContext) => {
    const {name} = _options;
    tree.create('hello.js',`console.log('Hello ${name}}!');`);
    return tree;
  };
}
 */
//2. Valida las opciones con Schema
//Ubicarse ./src/hello y ejecutar npx -p dtsgenerator dtsgen schema.json -o schema.d.ts
/* export function hello(_options: Schema): Rule {
  return (tree: Tree, _context: SchematicContext) => {
    const {name} = _options;
    tree.create('hello.js',`console.log('Hello ${name}!');`);
    return tree;
  };
}
 */
//3. usando templates
// schematics .:hello --debug=false --force
import { strings, JsonObject, json} from '@angular-devkit/core';

export function hello(_options: Schema): Rule {
  return (tree: Tree, _context: SchematicContext) => {

    const workspaceConfigBuffer = tree.read("angular.json");
    if(!workspaceConfigBuffer){
      throw new SchematicsException("No es un proyecto angular");
    }
    const workspaceConfig = JsonValue.parseJson(workspaceConfigBuffer.toString(),undefined, Parsejsono JsonObject);
    const projectName = _options.project || workspaceConfig.defaultProject;

    const sourceTemplate = url('./files');
    const sourceParametrizedTemplates = apply(sourceTemplate, [template({..._options,...strings, addExclamation})]);
    return mergeWith(sourceParametrizedTemplates)(tree, _context); //une el template con el arbol
  };

  function addExclamation(value: string): string{
    return value + '!';
  }
}
