import { Rule } from '@angular-devkit/schematics';
import { Schema } from './schema';
export declare function hello(_options: Schema): Rule;
