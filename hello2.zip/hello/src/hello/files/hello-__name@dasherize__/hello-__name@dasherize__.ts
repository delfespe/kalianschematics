<% if(transform) {%>
console.log('Bievenido <%= addExclamation(name) %>');
<%} else {%>
console.log('Hola <%= name %> ');
<% }%>
