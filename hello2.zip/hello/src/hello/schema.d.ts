export interface Schema{
    name:string;
    project?:string;
    transform?:boolean;
}